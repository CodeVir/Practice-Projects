﻿using System;

namespace Temp
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("What do you want to call your critter?");
            var name = Console.ReadLine();
            Critter bob = new Critter(name);
            while (bob.getIsAlive())
            {
                Console.WriteLine("What would you like Critter to do?");
                string lineRead = Console.ReadLine();
                if (lineRead.Equals("eat"))
                {
                    bob.feed();
                }
                else if (lineRead.Equals("sleep"))
                {
                    bob.sleep();
                }
                else if (lineRead.Equals("exercise"))
                {
                  bob.exercise();
                }
            }
            Console.WriteLine("Critter has died.");
            Console.ReadKey();
        }
     }
  }
