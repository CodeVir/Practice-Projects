using System;

namespace Temp
{
    public class Critter
    {
        private string name;
        private bool isAlive;
        private int foodLevel;
        private int tiredness;
        private int fitness;

        public Critter(string name)
        {
            isAlive = true;
            foodLevel = 5;
            tiredness = 0;
            fitness = 0;
            this.name = name;
        }

        public bool getIsAlive()
        {
            return isAlive;
        }

        private void die()
        {
            isAlive = false;
        }

      

        public void sleep()
        {
            Console.WriteLine($"{name} sleeps.");
            tiredness = 0;
            foodLevel -= 3;
            if (foodLevel <= 0)
            {
                Console.WriteLine($"{name} starves to death.");
                die();
            }
        }

        public void feed()
        {
            if (isAlive)
            {
                Console.WriteLine($"{name} eats.");
                foodLevel++;
                tiredness++;
                if (foodLevel > 10)
                {
                    Console.WriteLine($"{name} over ate.");
                    die();
                }
                else if (tiredness > 5)
                {
                    Console.WriteLine($"{name} is sleepy from so much food.");
                    sleep();
                }
              }
            }
        public void exercise()
        {
          if (isAlive)
          {
            Console.WriteLine($"{name} exercises.");
            fitness++;
            tiredness++;
            if (tiredness > 5)
            {
              Console.WriteLine($"{name} is sleepy from all the exercise.");
              sleep();
            }
            else if (fitness >= 10)
              {
                Console.WriteLine($"{name} is really fit!");
                Console.ReadKey();
              }
            }
          }
        }
      }
    